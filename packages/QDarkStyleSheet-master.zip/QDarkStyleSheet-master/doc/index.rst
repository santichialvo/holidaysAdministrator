.. QDarkStyle documentation master file, created by
   sphinx-quickstart on Tue May  8 14:23:26 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to QDarkStyle's documentation!
======================================

.. toctree::
   :maxdepth: 2

   readme.rst
   build/example/index.rst
   build/reference/index.rst
   build/script/index.rst
   changes.rst
   contributing.rst
   authors.rst
   license.rst
   code_of_conduct.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
